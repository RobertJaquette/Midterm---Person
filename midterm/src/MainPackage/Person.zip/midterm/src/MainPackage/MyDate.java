package MainPackage;

public class MyDate {
	
	private int Year;
	private int Month;
	private int Day;


	@Override
	public String toString() {
	    StringBuilder builder = new StringBuilder();
		return builder.toString();
	}


}